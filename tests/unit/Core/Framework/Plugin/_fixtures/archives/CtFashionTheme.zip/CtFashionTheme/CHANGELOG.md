# 1.0.0
- initialized CtFashionTheme
* refactored composer.json

# 1.0.1
- added migrations
* done nothing