<?php declare(strict_types=1);

namespace CtFashionTheme;

use Contena\Core\Framework\Plugin;

class CtFashionTheme extends Plugin {

}
